package no.hvl.dat100.jplab11.oppgave7;

public class Configuration {

		public static int SERVERPORT = 8080;
		
		public static String SERVER = "localhost";
		
		public static int N = 3;
		
}
